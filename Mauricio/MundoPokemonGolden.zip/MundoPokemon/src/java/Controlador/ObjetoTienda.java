/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

/**
 *
 * @author Mazamo Dafter Dark
 */
public class ObjetoTienda {
    //Atributos
    public String nombre;
    public String descripcion;
    public int precio;
    public String imagen;
    
    public int fk_objeto;
    public int fk_personaje;
    public int cantidad;
    //Métodos
    public ObjetoTienda(String nombre, String descripcion, int precio, String imagen){
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
    }
    public ObjetoTienda(String nombre, String descripcion, int precio, String imagen, int fk_objeto, int fk_personaje, int cantidad){
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
        this.fk_objeto = fk_objeto;
        this.fk_personaje = fk_personaje;
        this.cantidad = cantidad;
    }
    public ObjetoTienda(){}
}
