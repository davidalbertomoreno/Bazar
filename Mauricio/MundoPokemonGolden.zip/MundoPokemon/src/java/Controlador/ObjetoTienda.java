/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

/**
 *
 * @author Mazamo Dafter Dark
 */
public class ObjetoTienda {
    //Atributos
    public String nombre;
    public String descripcion;
    public int precio;
    public String imagen;
    
    public int cantidad;
    //Métodos
    public ObjetoTienda(String nombre, String descripcion, int precio, String imagen){
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
    }
    public ObjetoTienda(String nombre, String descripcion, int precio, String imagen, int cantidad){
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
        this.cantidad = cantidad;
    }
    public ObjetoTienda(){}
}
