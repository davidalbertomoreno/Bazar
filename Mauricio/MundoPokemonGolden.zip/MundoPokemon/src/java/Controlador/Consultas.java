package Controlador;

import java.sql.*;
import java.util.ArrayList;

public class Consultas extends Conexion{
	public boolean loggear(String nombre, String contraseña){
		PreparedStatement P = null;
		ResultSet R = null;
		try{
			String consulta = "select * from usuarios where nombre = ? and contraseña = ?";
			P = getConexion().prepareStatement(consulta);
			P.setString(1, nombre);
			P.setString(2, contraseña);
			R = P.executeQuery();
			if(R.absolute(1)){
				return true;
			}
		}
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		return false;
	}
	public boolean registrar(String nombre, String contraseña, String email){
		PreparedStatement P = null;
		try{
			String consulta = "insert into usuarios (nombre,contraseña,email) values (?,?,?)";
			P = getConexion().prepareStatement(consulta);
			P.setString(1, nombre);
			P.setString(2, contraseña);
			P.setString(3, email);
			if(P.executeUpdate() == 1){
				return true;
			}
		}
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(P != null) P.close();
			}
			catch(SQLException e){
			}
		}
		return false;
	}
	public boolean verificarPersonaje(String nombre){
		PreparedStatement P = null;
		ResultSet R = null;
		try{
			String consulta = "select * from usuarios inner join personajes on usuarios.id = personajes.fk_usuario where usuarios.nombre = ?";
			P = getConexion().prepareStatement(consulta);
			P.setString(1, nombre);
			R = P.executeQuery();
			if(R.absolute(1)){
				return true;
			}
		}
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(P != null) P.close();
				if(R != null) R.close();
			}
			catch(SQLException e){
			}
		}
		return false;
	}
	public boolean crearPersonaje(String nombre,int fk_usuario,String genero,String raza,String equipo, String COjos, String CPelo){
		PreparedStatement P = null;
		try{
			String consulta = "insert into personajes (nombre,fk_usuario,genero,raza,equipo,color_ojos,color_pelo) values (?,?,?,?,?,?,?)";
			P = getConexion().prepareStatement(consulta);
			P.setString(1, nombre);
			P.setInt(2, fk_usuario);
			P.setString(3, genero);
			P.setString(4, raza);
			P.setString(5, equipo);
			P.setString(6, COjos);
			P.setString(7, CPelo);
			if(P.executeUpdate() == 1){
				return true;
			}
		}
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(P != null) P.close();
			}
			catch(SQLException e){
			}
		}
		return false;
	}
	public String getID(String nombre){
		PreparedStatement P = null;
		ResultSet R = null;
		try{
			String consulta = "select id from usuarios where nombre = ?";
			P = getConexion().prepareStatement(consulta);
			P.setString(1, nombre);
			R = P.executeQuery();
			while(R.next()){
				return R.getString(1);
			}
		}
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(R != null) R.close();
			}
			catch(SQLException e){
			}
		}
		return null;
	}
    public ResultSet cargarPersonaje(String nombre_usuario){
		PreparedStatement PS;
		ResultSet RS = null;
		try{
			String consulta = "select personajes.nombre, personajes.nivel, personajes.genero, personajes.raza, personajes.equipo, personajes.color_ojos, personajes.color_pelo, personajes.medalla1, personajes.medalla2, personajes.medalla3, personajes.pokemoneda, personajes.experiencia from personajes inner join usuarios on personajes.fk_usuario=usuarios.id where usuarios.nombre=?";
			PS = getConexion().prepareStatement(consulta);
			PS.setString(1, nombre_usuario);
			RS = PS.executeQuery();
            }
            catch(SQLException e){System.err.println("Error: "+e);}
            return RS;
	}
    public ResultSet cargarPokemons(String usuario){
		PreparedStatement PS;
		ResultSet RS = null;
		try{
			String consulta = "select pokemons.imagen, pokemons.nombre, pokedexs.alias, pokemons.tipo, pokemons.especie, pokedexs.nivel, pokedexs.salud, pokedexs.id, pokedexs.estado, pokemons.id from pokedexs inner join personajes on pokedexs.fk_personaje = personajes.id inner join usuarios on personajes.fk_usuario = usuarios.id inner join pokemons on pokedexs.fk_pokemon = pokemons.id where usuarios.nombre = ?";
			PS = getConexion().prepareStatement(consulta);
			PS.setString(1, usuario);
			RS = PS.executeQuery();
            }
            catch(SQLException e){}
			/*finally{
				try{
					if(getConexion() != null) getConexion().close();
					if(PS != null) PS.close();
					if(RS != null) RS.close();
				}
				catch(SQLException e){
					System.err.println("Error: "+e);
				}
			}*/
            return RS;
	}
	public ResultSet cargarPokedex(){
		PreparedStatement PS;
		ResultSet RS = null;
		try{
			String consulta = "select imagen, nombre, tipo, especie, id from pokemons";
			PS = getConexion().prepareStatement(consulta);
			RS = PS.executeQuery();
            }
        catch(SQLException e){}
			/*finally{
				try{
					if(getConexion() != null) getConexion().close();
					if(PS != null) PS.close();
					if(RS != null) RS.close();
				}
				catch(SQLException e){
					System.err.println("Error: "+e);
				}
			}*/
        return RS;
	}
	public boolean liberarPokemon(int id){
		PreparedStatement P = null;
		try{
			String consulta = "delete from pokedexs where id=?";
			P = getConexion().prepareStatement(consulta);
			P.setInt(1, id);
			if(P.executeUpdate() == 1){
				return true;
			}
        }
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(P != null) P.close();
			}
			catch(SQLException e){
				System.err.println("Error: "+e);
			}
		}
		return false;
	}
	public boolean renombrarPokemon(int id, String rename){
		PreparedStatement P = null;
		try{
			String consulta = "update pokedexs set alias='"+rename+"' where id = ?";
			P = getConexion().prepareStatement(consulta);
			P.setInt(1, id);
			if(P.executeUpdate() == 1){
				return true;
			}
        }
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(P != null) P.close();
			}
			catch(SQLException e){
				System.err.println("Error: "+e);
			}
		}
		return false;
	}
	
	public boolean asignarPokemon(int id){
		PreparedStatement P = null;
		try{
			String consulta = "update pokedexs set estado=1 where id = ?";
			P = getConexion().prepareStatement(consulta);
			P.setInt(1, id);
			if(P.executeUpdate() == 1){
				return true;
			}
        }
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(P != null) P.close();
			}
			catch(SQLException e){
				System.err.println("Error: "+e);
			}
		}
		return false;
	}
	
	public boolean desasignarPokemon(int id){
		PreparedStatement P = null;
		try{
			String consulta = "update pokedexs set estado=0 where id = ?";
			P = getConexion().prepareStatement(consulta);
			P.setInt(1, id);
			if(P.executeUpdate() == 1){
				return true;
			}
        }
		catch(SQLException e){
			System.err.println("Error: "+e);
		}
		finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(P != null) P.close();
			}
			catch(SQLException e){
				System.err.println("Error: "+e);
			}
		}
		return false;
	}
	
	public int getCharacterID(String usuario){
            int id = 0;
			PreparedStatement PS;
			ResultSet RS;
			try{
				String Consulta = "select personajes.id from personajes inner join usuarios on personajes.fk_usuario = usuarios.id where usuarios.nombre = ?";
				PS = getConexion().prepareStatement(Consulta);
				PS.setString(1,usuario);
				RS = PS.executeQuery();
				while(RS.next()){
					id = Integer.parseInt(RS.getString(1));
				}
				return id;
			}
			catch(SQLException e){
				System.err.println("Error: "+e);
			}
		return id;
	}
	
	public ResultSet getBazarBuy(){
		PreparedStatement PS = null;
		ResultSet RS = null;
		try{
			String consulta = "select * from bazares";
			PS = getConexion().prepareStatement(consulta);
			RS = PS.executeQuery();
            }
        catch(SQLException e){}
		/*finally{
			try{
				if(getConexion() != null) getConexion().close();
				if(PS != null) PS.close();
			}
			catch(SQLException e){
				System.err.println("Error: "+e);
			}
		}*/
        return RS;
	}
    public ResultSet ventas (String usuario){
        PreparedStatement PS;
        ResultSet RS = null;  
        try{
            String consulta="select bazares.nombre,bazares.descripcion,bazares.precio,bazares.imagen,mochila.cantidad from mochila inner join bazares on mochila.fk_objeto = bazares.id inner join personajes on mochila.fk_personaje = personajes.id inner join usuarios on fk_usuario=usuarios.id where usuarios.nombre=?";
            PS = getConexion().prepareStatement(consulta);
            PS.setString(1, usuario);
            RS = PS.executeQuery();
            
        }
        catch(SQLException e){
            System.err.println("error: "+e);
        }
        return RS;
    }
        /*public static void main (String[]args){
            Consultas C = new Consultas();
            System.out.println(C.getCharacterID("Lucile Guerra"));
        }
	public static void main (String[] args){
		Consultas C = new Consultas();
                ResultSet RS;
                RS = C.cargarPokemons("Mauricio Sarmiento");
                ArrayList <Pokemon> pkmn = new ArrayList<Pokemon>();
		Pokemon Poke;
                try{
                    while(RS.next()){
                        Poke = new Pokemon(RS.getString(1),RS.getString(2),RS.getString(3),RS.getString(4),RS.getString(5),RS.getString(6),RS.getString(7),RS.getString(8),RS.getString(9),RS.getString(10));
                        pkmn.add(Poke);
                    }
                    for(Pokemon PK : pkmn){
                        System.out.println(PK.apodo);
                        System.out.println(PK.estado);
                    }
                }
                catch(SQLException e){
                    System.err.println("Error: "+e);
                }
	}*/
}