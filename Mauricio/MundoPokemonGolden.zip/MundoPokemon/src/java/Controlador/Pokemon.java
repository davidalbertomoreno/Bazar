/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

/**
 *
 * @author Mazamo Dafter Dark
 */
public class Pokemon {
    
	public String imagen;
	public String nombre;
	public String apodo;
	public String tipo;
	public String especie;
	public String nivel;
	public String salud;
	public String id;
	public String estado;
	public String idpkmn;
        
	public Pokemon(){
            
        }
	public Pokemon(String imagen, String nombre, String apodo, String tipo, String especie, String nivel, String salud, String id, String estado, String idpkmn){
		this.imagen = imagen;
		this.nombre = nombre;
		this.apodo = apodo;
		this.tipo = tipo;
		this.especie = especie;
		this.nivel = nivel;
		this.salud = salud;
		this.id = id;
		this.estado = estado;
		this.idpkmn = idpkmn;
	}
}
