function clickObj(valor_ID){
	var ID = valor_ID;
	var nombre = document.getElementById('nombre'+ID).innerHTML;
	var descripcion = document.getElementById('descripcion'+ID).innerHTML;
	var precio = document.getElementById('precio'+ID).innerHTML;
	var imagen = document.getElementById('imagen'+ID).src;
	
	location.replace("#openModal")
	
	document.getElementById('ObjNombre').innerHTML = nombre;
	document.getElementById('ObjDescripcion').innerHTML = descripcion;
	document.getElementById('ObjImagen').src = imagen;
	document.getElementById('ObjPrecio').value = precio;
}