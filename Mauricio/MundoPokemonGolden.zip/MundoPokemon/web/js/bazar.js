function clickObj(valor_ID){
	var ID = valor_ID;
	var nombre = document.getElementById('nombre'+ID).innerHTML;
	var descripcion = document.getElementById('descripcion'+ID).innerHTML;
	var precio = parseInt(document.getElementById('precio'+ID).innerHTML);
	var imagen = document.getElementById('imagen'+ID).src;
	
	location.replace("#openModal");
	
	document.getElementById('ObjCantidad').value = 1;
	document.getElementById('ObjNombre').innerHTML = nombre;
	document.getElementById('ObjDescripcion').innerHTML = descripcion;
	document.getElementById('ObjImagen').src = imagen;
	document.getElementById('ObjPrecio').value = precio;
	document.getElementById('ObjPrecioBase').value = precio;
}

function clickObjVender(valor_ID){
	var ID = valor_ID;
	var cantidad = document.getElementById('cantidad'+ID).innerHTML;
	var nombre = document.getElementById('nombre'+ID).innerHTML;
	var descripcion = document.getElementById('descripcion'+ID).innerHTML;
	var precio = (parseInt(document.getElementById('precio'+ID).innerHTML))/2;
	var imagen = document.getElementById('imagen'+ID).src;
	
	location.replace("#openModal");
	
	document.getElementById('ObjCantidad').value = cantidad;
	document.getElementById('ObjNombre').innerHTML = nombre;
	document.getElementById('ObjDescripcion').innerHTML = descripcion;
	document.getElementById('ObjImagen').src = imagen;
	document.getElementById('ObjPrecio').value = precio*parseInt(cantidad);
	document.getElementById('ObjPrecioBase').value = precio;
}

function cambiarCantidad(){
	var precio = parseInt(document.getElementById('ObjPrecioBase').value);
	var cantidad = parseInt(document.getElementById('ObjCantidad').value);
	
	document.getElementById('ObjPrecio').value = precio*cantidad;
}